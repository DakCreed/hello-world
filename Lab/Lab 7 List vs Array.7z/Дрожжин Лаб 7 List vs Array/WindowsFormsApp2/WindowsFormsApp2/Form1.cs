﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<SmallData> SmallList = new List<SmallData>();//список односвязный с легкой датой
        DoublyLinkedList<SmallData> smlinkedList = new DoublyLinkedList<SmallData>();//список двусвязный с легкой датой
        List<LargeData> LargeList = new List<LargeData>();//список односвязный с тяжелой датой
        DoublyLinkedList<LargeData> dlinkedList = new DoublyLinkedList<LargeData>();//список двусвязный с тяжелой датой
        //создаем лёгкую структуру
        unsafe struct SmallData

        {
            public fixed byte a[16];
        }
        //создаем тяжелую структуру
        unsafe struct LargeData
        {
            public fixed byte a[10240];
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int StartTime, ResultTime;
            LargeData EmptyValue;
            StartTime = Environment.TickCount;
            LargeData[] exampl = new LargeData[1];

            for (int i = 0; i < 2500; i++)
            {
                Array.Resize(ref exampl, exampl.Length + 1);
                exampl[i] = EmptyValue;
            }

            ResultTime = Environment.TickCount - StartTime;
            MessageBox.Show(String.Format("Время выполнения {0:f2} сек", (float)ResultTime / 1000.0));




        }

        public void button2_Click(object sender, EventArgs e)
        {
            string result = string.Empty;
            #region стек на динамическом массиве ПРОТАЛКИВАЕМ
            int StartTime, ResultTime;
            StartTime = Environment.TickCount;
            LargeData exampl;//вводим переменную которую будем доабвлять и удалять в цикле
            StackArray<LargeData> numbers = new StackArray<LargeData>(1);//инициируем список элементов
            for (int i = 0; i < 2500; i++)
            {
                numbers.Push(exampl);
            }
            ResultTime = Environment.TickCount - StartTime;
            result += (String.Format("Время выполнения  ПРОТАЛКИВАНИЯ {0:f2} сек   ", (float)ResultTime / 1000.0));
            #endregion
            #region стек на динамическом массиве ВЫТАЛКИВАЕМ
            int StartTime1, ResultTime1;
            StartTime1 = Environment.TickCount;


            for (int i = 0; i < numbers.Count; i++)
            {
                numbers.Pop();
            }
            ResultTime1 = Environment.TickCount - StartTime1;
            result += (String.Format("Время выполнения ВЫТАЛКИВАНИЯ {0:f2} сек ", (float)ResultTime1 / 1000.0));
            MessageBox.Show(result);
            #endregion

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string result = string.Empty;
            #region стек на динамическом массиве ПРОТАЛКИВАЕМ
            int StartTime, ResultTime;
            StartTime = Environment.TickCount;
            SmallData exampl;
            StackArray<SmallData> numbers = new StackArray<SmallData>(1);
            for (int i = 0; i < 2500; i++)
            {
                numbers.Push(exampl);
            }
            ResultTime = Environment.TickCount - StartTime;
            result += (String.Format("Время выполнения  ПРОТАЛКИВАНИЯ {0:f2} сек   ", (float)ResultTime / 1000.0));
            #endregion
            #region стек на динамическом массиве ВЫТАЛКИВАЕМ
            int StartTime1, ResultTime1;
            StartTime1 = Environment.TickCount;


            for (int i = 0; i < numbers.Count; i++)
            {
                numbers.Pop();
            }
            ResultTime1 = Environment.TickCount - StartTime1;
            result += (String.Format("Время выполнения ВЫТАЛКИВАНИЯ {0:f2} сек", (float)ResultTime1 / 1000.0));
            #endregion
            MessageBox.Show(result);
        }

        private void button4_Click(object sender, EventArgs e)
        {

            int StartTime, ResultTime;
            SmallData EmptyValue;
            StartTime = Environment.TickCount;
            SmallData[] exampl = new SmallData[1];

            for (int i = 0; i < 2500; i++)
            {
                Array.Resize(ref exampl, exampl.Length + 1);
                exampl[i] = EmptyValue;
            }

            ResultTime = Environment.TickCount - StartTime;
            MessageBox.Show(String.Format("Время выполнения {0:f2} сек", (float)ResultTime / 1000.0));
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

            string result = string.Empty;
            #region  Односвязый список ДОБАВЛЕНИЕ тяжелый
            int StartTime, ResultTime;
            LargeData exampl;
            StartTime = Environment.TickCount;
            Queue<LargeData> numbers = new Queue<LargeData>();
            numbers.Enqueue(exampl);
            for (int i = 0; i < 2500; i++)
            {
                numbers.Enqueue(exampl);

            }
            ResultTime = Environment.TickCount - StartTime;
            result += (String.Format("Время выполнения добавления {0:f2} сек  ", (float)ResultTime / 1000.0));
            #endregion
            #region Односвязный список УДАЛЕНИЕ тяжелый
            int StartTime1, ResultTime1;
            StartTime1 = Environment.TickCount;
            for (int i = 0; i < 2500; i++)
            {
                numbers.Dequeue();
            }
            ResultTime1 = Environment.TickCount - StartTime1;
            result += (String.Format("Время выполнения удаления {0:f2} сек", (float)ResultTime1 / 1000.0));
            #endregion

            MessageBox.Show(result);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string result = string.Empty;
            #region  Односвязый список ДОБАВЛЕНИЕ легкий
            int StartTime, ResultTime;
            SmallData exampl;
            StartTime = Environment.TickCount;
            Queue<SmallData> numbers = new Queue<SmallData>();
            numbers.Enqueue(exampl);
            for (int i = 0; i < 2500; i++)
            {
                numbers.Enqueue(exampl);

            }
            ResultTime = Environment.TickCount - StartTime;
            result += (String.Format("Время выполнения добавления {0:f2} сек  ", (float)ResultTime / 1000.0));
            #endregion
            #region Односвязный список УДАЛЕНИЕ легкий
            int StartTime1, ResultTime1;
            StartTime1 = Environment.TickCount;
            for (int i = 0; i < 2500; i++)
            {
                numbers.Dequeue();
            }
            ResultTime1 = Environment.TickCount - StartTime1;
            result += (String.Format("Время выполнения удаления {0:f2} сек", (float)ResultTime1 / 1000.0));
            #endregion

            MessageBox.Show(result);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            #region Стэк на основе списка ПРОТАЛКИВАНИЕ
            string result = string.Empty;
            int StartTime, ResultTime;
            StartTime = Environment.TickCount;
            LargeData exampl;
            NodeStack<LargeData> stack = new NodeStack<LargeData>();
            for (int i = 0; i < stack.Count; i++)
            {
                stack.Push(exampl);
            }
            ResultTime = Environment.TickCount - StartTime;
            result += (String.Format("Время выполнения ПРОТАЛКИВАНИЯ {0:f2} сек", (float)ResultTime / 1000.0));
            #endregion
            #region Стэк на основе списка ВЫТАЛКИВАНИЕ

            int StartTime1, ResultTime1;
            StartTime1 = Environment.TickCount;
            for (int i = 0; i < stack.Count; i++)
            {
                stack.Pop();
            }
            ResultTime1 = Environment.TickCount - StartTime1;
            result += (String.Format("Время выполнения ВЫТАЛКИВАНИЯ {0:f2} сек", (float)ResultTime / 1000.0));
            #endregion
            MessageBox.Show(result);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            #region Стэк на основе списка ПРОТАЛКИВАНИЕ
            string result = string.Empty;
            int StartTime, ResultTime;
            StartTime = Environment.TickCount;
            SmallData exampl;
            NodeStack<SmallData> stack = new NodeStack<SmallData>();
            for (int i = 0; i < stack.Count; i++)
            {
                stack.Push(exampl);
            }
            ResultTime = Environment.TickCount - StartTime;
            result += (String.Format("Время выполнения ПРОТАЛКИВАНИЯ {0:f2} сек", (float)ResultTime / 1000.0));
            #endregion
            #region Стэк на основе списка ВЫТАЛКИВАНИЕ

            int StartTime1, ResultTime1;
            StartTime1 = Environment.TickCount;
            for (int i = 0; i < stack.Count; i++)
            {
                stack.Pop();
            }
            ResultTime1 = Environment.TickCount - StartTime1;
            result += (String.Format("Время выполнения ВЫТАЛКИВАНИЯ {0:f2} сек", (float)ResultTime / 1000.0));
            #endregion
            MessageBox.Show(result);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            #region задание с добавление в ДВУСВЯЗНЫЕ списки
            string result = string.Empty;//строка для результат
            int StartTime, ResultTime;
            StartTime = Environment.TickCount;
            LargeData example;
            for (int i = 0; i < 2500; i++)
            {
                dlinkedList.AddFirst(example);
            }
            ResultTime = Environment.TickCount - StartTime;
            result += (String.Format("Время выполнения добавления {0:f2} сек   ", (float)ResultTime / 1000.0));//время первой операции
            #endregion
            int StartTime1, ResultTime1;
            StartTime1 = Environment.TickCount;
            for (int i = 0; i < 2500; i++)
            {
                dlinkedList.Remove(example);
            }
            ResultTime1 = Environment.TickCount - StartTime1;
            result += (String.Format("Время выполнения удаления {0:f2} сек", (float)ResultTime / 1000.0));
            MessageBox.Show(result);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            {
                #region задание с добавление в ДВУСВЯЗНЫЕ списки
                string result = string.Empty;//строка для результат
                int StartTime, ResultTime;
                StartTime = Environment.TickCount;
                SmallData example;
                for (int i = 0; i < 2500; i++)
                {
                    smlinkedList.AddFirst(example);
                }
                ResultTime = Environment.TickCount - StartTime;
                result += (String.Format("Время выполнения добавления {0:f2} сек  ", (float)ResultTime / 1000.0));//время первой операции
                #endregion
                int StartTime1, ResultTime1;
                StartTime1 = Environment.TickCount;
                for (int i = 0; i < 2500; i++)
                {
                    smlinkedList.Remove(example);
                }
                ResultTime1 = Environment.TickCount - StartTime1;
                result += (String.Format("Время выполнения удаления {0:f2} сек", (float)ResultTime / 1000.0));
                MessageBox.Show(result);
            }
        }
        public class StackArray<T>//класс стека на массивах
        {
            private T[] items;
            private int count;
            const int n = 1;
            public StackArray()
            {
                items = new T[n];
            }
            public StackArray(int length)
            {
                items = new T[length];
            }

            public bool IsEmpty
            {
                get { return count == 0; }
            }
            public int Count
            {
                get { return count; }
            }

            public void Push(T item)
            {
                // увеличиваем стек
                if (count == items.Length)
                    Resize(items.Length + 1);

                items[count++] = item;
            }
            public T Pop()
            {
                // если стек пуст, выбрасываем исключение
                if (IsEmpty)
                    throw new InvalidOperationException("Стек пуст");
                T item = items[--count];
                items[count] = default(T); // сбрасываем ссылку

                if (count > 0 && count < items.Length - 1)
                    Resize(items.Length - 1);

                return item;
            }
            public T Peek()
            {
                return items[count - 1];
            }

            private void Resize(int max)
            {
                T[] tempItems = new T[max];
                for (int i = 0; i < count; i++)
                    tempItems[i] = items[i];
                items = tempItems;
            }
        }
        public class Node<T>
        {
            public Node(T data)
            {
                Data = data;
            }
            public T Data { get; set; }
            public Node<T> Next { get; set; }
        }
        public class NodeStack<T> : IEnumerable<T>
        {
            Node<T> head;
            int count;

            public bool IsEmpty
            {
                get { return count == 0; }
            }
            public int Count
            {
                get { return count; }
            }

            public void Push(T item)
            {
                // увеличиваем стек
                Node<T> node = new Node<T>(item);
                node.Next = head; // переустанавливаем верхушку стека на новый элемент
                head = node;
                count++;
            }
            public T Pop()
            {
                // если стек пуст, выбрасываем исключение
                if (IsEmpty)
                    throw new InvalidOperationException("Стек пуст");
                Node<T> temp = head;
                head = head.Next; // переустанавливаем верхушку стека на следующий элемент
                count--;
                return temp.Data;
            }
            public T Peek()
            {
                if (IsEmpty)
                    throw new InvalidOperationException("Стек пуст");
                return head.Data;
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return ((IEnumerable)this).GetEnumerator();
            }

            IEnumerator<T> IEnumerable<T>.GetEnumerator()
            {
                Node<T> current = head;
                while (current != null)
                {
                    yield return current.Data;
                    current = current.Next;
                }
            }
        }
        public class DoublyNode<T>//класс узла двусвязного списка
        {
            public DoublyNode(T data)
            {
                Data = data;
            }
            public T Data { get; set; }
            public DoublyNode<T> Previous { get; set; }
            public DoublyNode<T> Next { get; set; }
        }
        public class DoublyLinkedList<T> : IEnumerable<T>  // двусвязный список
        {
            DoublyNode<T> head; // головной/первый элемент
            DoublyNode<T> tail; // последний/хвостовой элемент
            int count;  // количество элементов в списке

            // добавление элемента
            public void Add(T data)
            {
                DoublyNode<T> node = new DoublyNode<T>(data);

                if (head == null)
                    head = node;
                else
                {
                    tail.Next = node;
                    node.Previous = tail;
                }
                tail = node;
                count++;
            }
            public void AddFirst(T data)
            {
                DoublyNode<T> node = new DoublyNode<T>(data);
                DoublyNode<T> temp = head;
                node.Next = temp;
                head = node;
                if (count == 0)
                    tail = head;
                else
                    temp.Previous = node;
                count++;
            }
            // удаление
            public bool Remove(T data)
            {
                DoublyNode<T> current = head;

                // поиск удаляемого узла
                while (current != null)
                {
                    if (current.Data.Equals(data))
                    {
                        break;
                    }
                    current = current.Next;
                }
                if (current != null)
                {
                    // если узел не последний
                    if (current.Next != null)
                    {
                        current.Next.Previous = current.Previous;
                    }
                    else
                    {
                        // если последний, переустанавливаем tail
                        tail = current.Previous;
                    }

                    // если узел не первый
                    if (current.Previous != null)
                    {
                        current.Previous.Next = current.Next;
                    }
                    else
                    {
                        // если первый, переустанавливаем head
                        head = current.Next;
                    }
                    count--;
                    return true;
                }
                return false;
            }

            public int Count { get { return count; } }
            public bool IsEmpty { get { return count == 0; } }

            public void Clear()
            {
                head = null;
                tail = null;
                count = 0;
            }

            public bool Contains(T data)
            {
                DoublyNode<T> current = head;
                while (current != null)
                {
                    if (current.Data.Equals(data))
                        return true;
                    current = current.Next;
                }
                return false;
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return ((IEnumerable)this).GetEnumerator();
            }

            IEnumerator<T> IEnumerable<T>.GetEnumerator()
            {
                DoublyNode<T> current = head;
                while (current != null)
                {
                    yield return current.Data;
                    current = current.Next;
                }
            }

            public IEnumerable<T> BackEnumerator()
            {
                DoublyNode<T> current = tail;
                while (current != null)
                {
                    yield return current.Data;
                    current = current.Previous;
                }
            }
        }
    }
}

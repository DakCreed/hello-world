﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Structures
{
    public partial class Form1 : Form
    {
        struct Person
        {
            public int Shifr;
            public String SubName;
            public String Name;
            public String Patronymic;
            public int DenRozdeniya;
            public string Specialnost;
            public int exp;
            public static bool operator >(Person a, int CompareExp)
            {
                return a.exp > CompareExp;
            }
            public static bool operator <(Person a, int CompareExp)
            {
                return a.exp < CompareExp;
            }
            public static bool operator ==(Person a, string SearchSpecialty)
            {
                return a.Specialnost == SearchSpecialty;
            }
            public static bool operator !=(Person a, string SearchSpecialty)
            {
                return a.Specialnost != SearchSpecialty;
            }
            public static bool operator ==(Person a, Person b)
            {
                return (a.exp == b.exp && a.DenRozdeniya == b.DenRozdeniya); // ||(a.Specialnost == b.Specialnost && a.exp == b.exp);
            }
            public static bool operator !=(Person a, Person b)
            {
                return (a.exp == b.exp && a.DenRozdeniya == b.DenRozdeniya); //|| (a.Specialnost == b.Specialnost && a.exp == b.exp);
            }
        }
        List<Person> persons = new List<Person>();
        List<int> Sovpadeniya = new List<int>();
        List<int> persons1 = new List<int>();
        int[] Set = { };
        int Count = 0;
        int CompareExp = 0;
        string SearchSpecialty = "";


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Person p;
            p.Shifr = Convert.ToInt32(textBox7.Text);
            p.SubName = textBox1.Text;
            p.Name = textBox2.Text;
            p.Patronymic = textBox3.Text;
            p.DenRozdeniya = Convert.ToInt32(textBox4.Text);
            p.Specialnost = textBox5.Text;
            p.exp = Convert.ToInt32(textBox6.Text);
            persons.Add(p);
            ListViewItem a = new ListViewItem();
            a.Text = Convert.ToString(p.Shifr);
            ListViewItem.ListViewSubItem b = new ListViewItem.ListViewSubItem();
            b.Text = p.SubName;
            ListViewItem.ListViewSubItem c = new ListViewItem.ListViewSubItem();
            c.Text = p.Name;
            ListViewItem.ListViewSubItem d = new ListViewItem.ListViewSubItem();
            d.Text = Convert.ToString(p.Patronymic);
            ListViewItem.ListViewSubItem f = new ListViewItem.ListViewSubItem();
            f.Text = Convert.ToString(p.DenRozdeniya);
            ListViewItem.ListViewSubItem g = new ListViewItem.ListViewSubItem();
            g.Text = Convert.ToString(p.Specialnost);
            ListViewItem.ListViewSubItem z = new ListViewItem.ListViewSubItem();
            z.Text = Convert.ToString(p.exp);
            a.SubItems.Add(b);
            a.SubItems.Add(c);
            a.SubItems.Add(d);
            a.SubItems.Add(f);
            a.SubItems.Add(g);
            a.SubItems.Add(z);
            listView1.Items.Add(a);
            Count++;

        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (listView1.SelectedItems.Count > 0)
            {
                foreach (ListViewItem eachItem in listView1.SelectedItems)
                {
                    listView1.Items.Remove(eachItem);

                }
            }
            else
                MessageBox.Show("Не выбран элемент");
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            CompareExp = Convert.ToInt32(textBox8.Text);

            string result = string.Empty;
            foreach (Person p in persons)
            {
                if (p.exp > CompareExp)
                {
                    result += (p.Shifr + " ");
                }

            }
            MessageBox.Show(" " + result);
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            SearchSpecialty = textBox9.Text;
            string result = string.Empty;
            foreach (Person p in persons)
            {
                if (p.Specialnost == SearchSpecialty)
                {
                    result += (p.Shifr + " ");
                }

            }
            MessageBox.Show(" " + result);
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            string result = string.Empty;
            Person[] arr = persons.ToArray();
            for (int i = 0; i < arr.Length; i++)
                if (arr.Count(x => x == arr[i]) > 1)
                {
                    result += (arr[i].Shifr + " ");
                }
            MessageBox.Show(" " + result);
            /*int a = 0;
            List<int> arr2 = new List<int>();
            string j = "";
            foreach (Person p in persons)
            {            
                a = p.exp + p.DenRozdeniya;
                persons1.Add(a);//заполняется уникальными суммами стажа и года рождения
                arr2.Add(p.Shifr);               
            }
            int[] newArr = arr2.ToArray();//создаем массив  с индексами и содержанием шифров
            List<int> arr = persons1;//из списка с уникальными суммами СТ+ГР производим массив, что бы заюзать цикл с ассоциативным массивом 
                     
            //цикл ищет совпадения в уникальных суммах Стажа и Года Рождения и выводит индексы совпадений
            for (int i = 0; i < arr.Count; i++)
                if (arr.Count(x => x == arr[i]) > 1)
                {
                    j += newArr[i];

                    //MessageBox.Show(j + " ");
                }
            
            MessageBox.Show("Шифры совпадений: " + j);
            persons1.Clear();
            */
        }

        private void button6_Click(object sender, EventArgs e)
        {

            Person[] arr = persons.ToArray();
            string resultShifr = string.Empty;
            /*
            for (int i = 0; i < arr.Length; i++)
                if (arr.Count(x => x == arr[i]) > 1)
                    MessageBox.Show(arr[i].Shifr + " ");
                    */

            for (int i = 0; i < arr.Length - 1; i++)
            {

                for (int j = i + 1; j < arr.Length; j++)
                {
                    if (arr[i].exp == arr[j].exp && arr[i].Specialnost == arr[j].Specialnost)
                    {

                        resultShifr += " " + i + " " + j;


                    }
                }
            }
            MessageBox.Show("Шифры совпадений " + resultShifr);
        }
    }
}
/*
  Console.Write("string: ");
            string str = Console.ReadLine(); 

            char[] delim = { ' ', ',', '.', ':', ';', '!', '?' };
            string[] tokens = str.Split(delim, StringSplitOptions.RemoveEmptyEntries);

            Dictionary<string, int> dictionary = new Dictionary<string, int>();
            foreach (string token in tokens)
            {
                if (dictionary.ContainsKey(token))
                    ++dictionary[token];
                else
                    dictionary[token] = 1;
            }

            foreach (KeyValuePair<string, int> pair in dictionary)
                Console.WriteLine("{0} -> {1}", pair.Key, pair.Value);
            Console.ReadKey();
            */

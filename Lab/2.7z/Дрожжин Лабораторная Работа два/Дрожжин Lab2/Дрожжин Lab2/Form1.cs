﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Дрожжин_Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Form2 newForm = new Form2();
            newForm.Show(); //Отображение элемента form2
            newForm.form1 = this;


        }
        enum Direction { Right, Down, Left, Up };
        Direction direction = Direction.Right;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            /*
            Form2 newForm = new Form2();
            newForm.Show();
            */
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            switch (direction) //функции для плавного изменения цвета
            {
                case Direction.Right: //переход зеленого в синий
                    label1.ForeColor = Color.FromArgb(0, (255 - label1.Left * 255 / (ClientRectangle.Width - label1.Width)), label1.Left * 255 / (ClientRectangle.Width - label1.Width));
                    break;
                case Direction.Down: //переход синего в розовый(маджента)
                    label1.ForeColor = Color.FromArgb(label1.Top * 255 / (ClientRectangle.Height - label1.Height), 0, 255);
                    break;
                case Direction.Left: //переход розового в желтый
                    label1.ForeColor = Color.FromArgb(255, (-label1.Left * 255 / (ClientRectangle.Width - label1.Width) + 255), (label1.Left * 255 / (ClientRectangle.Width - label1.Width)));
                    break;
                case Direction.Up: //переход желтого в зеленый
                    label1.ForeColor = Color.FromArgb(label1.Top * 255 / (ClientRectangle.Height - label1.Height), 255, 0);
                    break;
            }
            switch (direction)  //перемещение
            {
                case Direction.Right:
                    label1.Left += 10;
                    break;
                case Direction.Down:
                    label1.Top += 10;
                    break;
                case Direction.Left:
                    label1.Left -= 10;
                    break;
                case Direction.Up:
                    label1.Top -= 10;
                    break;
            }
            if (label1.Left > ClientRectangle.Width - label1.Width)  // функции для правильного масштабирования и границ
            {
                direction = Direction.Down;
                label1.Left = ClientRectangle.Width - label1.Width;


            }
            else if (label1.Top > ClientRectangle.Height - label1.Height)
            {
                direction = Direction.Left;
                label1.Top = ClientRectangle.Height - label1.Height;

            }
            else if (label1.Left < 0)
            {
                direction = Direction.Up;
                label1.Left = 0;

            }
            else if (label1.Top < 0)
            {
                direction = Direction.Right;
                label1.Top = 0;

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}


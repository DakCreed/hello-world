﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_Array
{

    public partial class Form1 : Form
    {
        static int GetNumber(int[] arr)
        {
            Array.Sort(arr);
            Array.Reverse(arr);
            int a = 0, b = 0;
            bool n1 = false, n2 = false;
            foreach (var obj in arr)
            {
                if (obj % 2 == 0)
                {

                    if (!n1)
                    {
                        n1 = true;
                        a = obj;
                    }
                    else if (!n2)
                    {
                        n2 = true;
                        b = obj;
                    }

                    if (n1 && n2) return a * b;
                }
            }
            return 0;
        }

        int[] static_array = new int[10];  // «статический» массив
        int[] dinamic_array = { };
        int[] md = { };
        int inputCount = 0;     // Счетчик элементов; это не просто 0, это первый из возможных индексов для m
        int TestMultiplay = 1; //переменная для произведения всех элементов
        int TwoMaxEvenNumbers = 0;
        int SumEvenIndex=0;
        int TheSumOfNegativeElements = 0;
        int TheNumberOfNegativeElements = 0;
        double MeanOfNegativeElementsArray = 0;
        int StaticAnswer = 0;

        int inputCount1 = 0;     // Счетчик элементов; это не просто 0, это первый из возможных индексов для m
        int TestMultiplay1 = 1; //переменная для произведения всех элементов
        int TwoMaxEvenNumbers1 = 0;
        int SumEvenIndex1 = 0;
        int TheSumOfNegativeElements1 = 0;
        int TheNumberOfNegativeElements1 = 0;
        double MeanOfNegativeElementsArray1 = 0;
        int StaticAnswer1 = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            #region Кнопка расчитать

            //начало произведения
            for (int i = 0; i < dinamic_array.Length; i++)
            {
                TestMultiplay1 *= dinamic_array[i];
            }
            label6.Text += "\r\n" + "произведение элементов " + TestMultiplay1;
            //конец произведения
            
            //начало вычисления суммы элементов с четными индексами
            for (int i = 0; i < dinamic_array.Length; i++)
            {
                if (i % 2 == 0)// если элемент четный
                {
                    SumEvenIndex1 += dinamic_array[i];
                }
                else
                {
                    continue;
                }
            }

            label6.Text += "\r\n" + "Сумма элементов с четными индексами " + SumEvenIndex1;
            //конец вычисления суммы элементов с четными индексами
            //начало вычисления  количества элементов меньше среднего отрицательного
            for (int i = 0; i < dinamic_array.Length; i++)
            {
                if (dinamic_array[i] < 0)
                {
                    TheNumberOfNegativeElements1++;
                    TheSumOfNegativeElements1 += dinamic_array[i];
                    MeanOfNegativeElementsArray1 = TheSumOfNegativeElements1 / TheNumberOfNegativeElements1;//нашли среднее отрицательное

                }

            }
            for (int i = 0; i < dinamic_array.Length; i++)
            {
                if (dinamic_array[i] < MeanOfNegativeElementsArray)
                {
                    StaticAnswer1++;
                }
            }
            label6.Text += "\r\n" + "количество элементов меньше среднего отрицательного " + StaticAnswer1;
            //конец вычисления  количества элементов меньше среднего отрицательного
            //начало умножение двух макс четных эллементов

            TwoMaxEvenNumbers1 = GetNumber(dinamic_array);

            /*
            Array.Sort(static_array1);
            Array.Reverse(static_array1);
            for (int i = 0; i < static_array1.Length; i++)
            {
                if (static_array1[i] % 2 != 0)
                {
                    static_array1[i] = 0;
                }
            }
            Array.Sort(static_array1);
            Array.Reverse(static_array1);
            TwoMaxEvenNumbers = static_array1[0] * static_array1[1];
            */
            label6.Text += "\r\n" + "произведение максимальных двух четных элементов " + TwoMaxEvenNumbers;
            


            //конец максимального двух четных произведений
           
            #endregion
        }

        private void button1_Click(object sender, EventArgs e)
        {
            #region Работа со статическим массивом
            int value;
            
            if ((int.TryParse(textBox1.Text, out value)))
            {
                
                static_array[inputCount] = value;//присваиваем введеное значение эелементу массива 
                
                label3.Text += "\r\n" + static_array[inputCount];
                inputCount++;
                
            }
            else
            {
                MessageBox.Show("Неверное значение");
            }
            if (inputCount >= 10)
            {
                //начало произведения
                for (int i = 0; i < static_array.Length; i++)
                {
                    TestMultiplay *= static_array[i];
                }
                label5.Text += "\r\n" + "произведение элементов " + TestMultiplay;
                //конец произведения

                //начало вычисления суммы элементов с четными индексами
                for (int i = 0; i < static_array.Length; i++)
                {
                    if (i % 2 == 0)// если элемент четный
                    {
                        SumEvenIndex += static_array[i];
                    }
                    else
                    {
                        continue;
                    }
                }

                label5.Text += "\r\n" + "Сумма элементов с четными индексами " + SumEvenIndex;
                //конец вычисления суммы элементов с четными индексами
                //начало вычисления  количества элементов меньше среднего отрицательного
                for (int i = 0; i < static_array.Length; i++)
                {
                    if (static_array[i] < 0)
                    {
                        TheNumberOfNegativeElements++;
                        TheSumOfNegativeElements += static_array[i];
                        MeanOfNegativeElementsArray = TheSumOfNegativeElements / TheNumberOfNegativeElements;//нашли среднее отрицательное

                    }

                }
                for (int i = 0; i < static_array.Length; i++)
                {
                    if (static_array[i] < MeanOfNegativeElementsArray)
                    {
                        StaticAnswer++;
                    }
                }
                label5.Text += "\r\n" + "количество элементов меньше среднего отрицательного " + StaticAnswer;
                //конец вычисления  количества элементов меньше среднего отрицательного
                //начало умножение двух макс четных эллементов

                TwoMaxEvenNumbers = GetNumber(static_array);

                /*
                Array.Sort(static_array1);
                Array.Reverse(static_array1);
                for (int i = 0; i < static_array1.Length; i++)
                {
                    if (static_array1[i] % 2 != 0)
                    {
                        static_array1[i] = 0;
                    }
                }
                Array.Sort(static_array1);
                Array.Reverse(static_array1);
                TwoMaxEvenNumbers = static_array1[0] * static_array1[1];
                */
                label5.Text += "\r\n" + "произведение максимальных двух четных элементов " + TwoMaxEvenNumbers;



                //конец максимального двух четных произведений

            }
            textBox1.Text = " ";

            #endregion
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int value;
            
            if (int.TryParse(textBox2.Text, out value))
            {
                int[] new_md = new int[dinamic_array.Length + 1];
                dinamic_array.CopyTo(new_md, 0); // Копируем старый массив в новый
                dinamic_array = new_md;
                dinamic_array[dinamic_array.Length - 1] = value;
                label4.Text += "\r\n" + value;
                // Добавляем в массив

            }
            else
            {
                MessageBox.Show("Неверное значение");
            }
            textBox2.Text = " ";

        }

        private void label4_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Array.Clear(static_array, 0, 10);
            
            label5.Text = "Результат:";
            label3.Text = "Масcив:";
            inputCount = 0;     // Счетчик элементов; это не просто 0, это первый из возможных индексов для m
            TestMultiplay = 1; //переменная для произведения всех элементов
            TwoMaxEvenNumbers = 0;
            StaticAnswer = 0;
            SumEvenIndex = 0;
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            
            

            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            dinamic_array = new int [0];
            label6.Text = "Результат:";
            label4.Text = "Масcив:";
            inputCount1 = 0;     // Счетчик элементов; это не просто 0, это первый из возможных индексов для m
            TestMultiplay1 = 1; //переменная для произведения всех элементов
            TwoMaxEvenNumbers1 = 0;
            StaticAnswer1 = 0;
            SumEvenIndex1 = 0;
        }

        private void label6_Click_1(object sender, EventArgs e)
        {

        }
    }
}

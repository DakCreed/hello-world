﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Drogjin_Lab6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string str = "";
        //string A = "";
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            str = textBox1.Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            StringBuilder b = new StringBuilder(str);
            
            listBox1.Items.Add(str);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string result = str.Replace("abc", "ПРЕВЕД");

            listBox2.Items.Add(result);
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int count = 0;
            string result;
            for (int i = 0; i < str.Length; i++)
            {
                if ((str[i] >= 'А' && str[i] <= 'я') || str[i] == 'ё' || str[i] == 'Ё')
                {
                    count++;
                }
            
            }
            result = "Количество русских букв: " + count;
            listBox2.Items.Add(result);
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            int count = 0;
            string result;
            if (str[0] >= '0' && str[0] <= '9')
            {
                count++;
            }
            for (int j = 1; j < str.Length; j++)
            {
                if (str[j] >= '0' && str[j] <= '9' && (str[j - 1] > '9' || str[j - 1] < '0'))
                    count++;
            }
            result = "Количество чисел в строке: " + count;
            listBox2.Items.Add(result);
        }

        private void button4_Click(object sender, EventArgs e)
        {
             string result;
            int d = 0;

            int t = 0;
            StringBuilder str1 = new StringBuilder(str);
            for (int i = 0; i < str1.Length; i++)
            {
                if (str1[i] == '.')
                    t++;
                if (str1[i] == '.' && t == 3)
                {
                    str1[i] = ':'; t = 0;
                }
            }

            listBox2.Items.Add(str1);
            
        } 
    }
}

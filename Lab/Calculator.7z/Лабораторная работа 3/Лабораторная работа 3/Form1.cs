﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лабораторная_работа_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a, b, res;

            if (double.TryParse(textBox1.Text, out a) && double.TryParse(textBox2.Text, out b))
            {
                res = a + b;
                MessageBox.Show("Результат: " + res.ToString());
                string s = "";
                s = a.ToString() + "+" + b.ToString() + " = " + (a + b).ToString();

                listBox1.Items.Add(s);
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            double a, b, res;

            if (double.TryParse(textBox1.Text, out a) && double.TryParse(textBox2.Text, out b))
            {
                res = a - b;
                MessageBox.Show("Результат: " + res.ToString());
                string s = "";
                s = a.ToString() + "-" + b.ToString() + " = " + (a - b).ToString();

                listBox1.Items.Add(s);
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double a, b, res;

            if (double.TryParse(textBox1.Text, out a) && double.TryParse(textBox2.Text, out b))
            {
                res = a * b;
                MessageBox.Show("Результат: " + res.ToString());
                string s = "";
                s = a.ToString() + "*" + b.ToString() + " = " + (a * b).ToString();

                listBox1.Items.Add(s);
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double a, b, res;

            if (double.TryParse(textBox1.Text, out a) && double.TryParse(textBox2.Text, out b))
            {
                res = a / b;
                MessageBox.Show("Результат: " + res.ToString());
                string s = "";
                s = a.ToString() + "/" + b.ToString() + " = " + (a / b).ToString();

                listBox1.Items.Add(s);
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            double a, b, res;

            if (double.TryParse(textBox1.Text, out a) && double.TryParse(textBox2.Text, out b))
            {
                res = a % b;
                MessageBox.Show("Результат: " + res.ToString());
                string s = "";
                s = a.ToString() + "%" + b.ToString() + " = " + (a % b).ToString();

                listBox1.Items.Add(s);
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            int a, b;
            int res;
            bool a1, b1, res1;

            if (int.TryParse(textBox1.Text, out a) && int.TryParse(textBox2.Text, out b))
            {
                res = a & b;
                MessageBox.Show("Результат: " + res.ToString());
                string s = "";
                s = a.ToString() + "&" + b.ToString() + " = " + (a & b).ToString();

                listBox1.Items.Add(s);
            }
            else
            {
                if (bool.TryParse(textBox1.Text, out a1) && bool.TryParse(textBox2.Text, out b1))
                {
                    res1 = a1 & b1;
                    MessageBox.Show("Результат: " + res1);
                    string s = "";
                    s = a1 + "&" + b1 + " = " + (a1 & b1);

                    listBox1.Items.Add(s);
                }

                else
                {
                    MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void button7_Click(object sender, EventArgs e)
        {


            int a, b;
            int res;
            bool a1, b1, res1;

            if (int.TryParse(textBox1.Text, out a) && int.TryParse(textBox2.Text, out b))
            {
                res = a | b;
                MessageBox.Show("Результат: " + res.ToString());
                string s = "";
                s = a.ToString() + "|" + b.ToString() + " = " + (a & b).ToString();

                listBox1.Items.Add(s);
            }
            else
            {
                if (bool.TryParse(textBox1.Text, out a1) && bool.TryParse(textBox2.Text, out b1))
                {
                    res1 = a1 | b1;
                    MessageBox.Show("Результат: " + res1);
                    string s = "";
                    s = a1 + "|" + b1 + " = " + (a1 | b1);

                    listBox1.Items.Add(s);
                }

                else
                {
                    MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void button8_Click(object sender, EventArgs e)
        {


            int a, b;
            int res;
            bool a1, b1, res1;

            if (int.TryParse(textBox1.Text, out a) && int.TryParse(textBox2.Text, out b))
            {
                res = a ^ b;
                MessageBox.Show("Результат: " + res.ToString());
                string s = "";
                s = a.ToString() + "^" + b.ToString() + " = " + (a ^ b).ToString();

                listBox1.Items.Add(s);
            }
            else
            {
                if (bool.TryParse(textBox1.Text, out a1) && bool.TryParse(textBox2.Text, out b1))
                {
                    res1 = a1 ^ b1;
                    MessageBox.Show("Результат: " + res1);
                    string s = "";
                    s = a1 + "^" + b1 + " = " + (a1 ^ b1);

                    listBox1.Items.Add(s);
                }

                else
                {
                    MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int a, res;
            

            if (!int.TryParse(textBox1.Text, out a))
            {
                
            };
            res = ~(a);
            string s = "";
            s = $"{a}Not{res}";
                
            listBox1.Items.Add(s);
            MessageBox.Show("Результат: " + res);

        }

        private void button10_Click(object sender, EventArgs e)
        {
            double a, b;
            if (double.TryParse(textBox1.Text, out a) && double.TryParse(textBox2.Text, out b))
            {
                if (a > b)
                {
                    MessageBox.Show($" {a} больше, чем {b}");
                    string s = "";
                    s = $" {a}больше, чем {b}";
                    listBox1.Items.Add(s);
                }
                else {
                    MessageBox.Show($" {a} не больше, чем {b}");
                    string s = "";
                    s = $" {a} не больше, чем {b}";
                    listBox1.Items.Add(s);
                }
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


}

        private void button11_Click(object sender, EventArgs e)
        {
            double a, b;
            if (double.TryParse(textBox1.Text, out a) && double.TryParse(textBox2.Text, out b))
            {
                if (a < b)
                {
                    MessageBox.Show($" {a} меньше, чем {b}");
                    string s = "";
                    s = $" {a}больше, чем {b}";
                    listBox1.Items.Add(s);
                }
                else
                {
                    MessageBox.Show($" {a} не меньше, чем {b}");
                    string s = "";
                    s = $" {a} не меньше, чем {b}";
                    listBox1.Items.Add(s);
                }
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            double a, b;
            if (double.TryParse(textBox1.Text, out a) && double.TryParse(textBox2.Text, out b))
            {
                if (a >= b)
                {
                    MessageBox.Show($" {a}  больше или равен {b}");
                    string s = "";
                    s = $" {a} больше или равен {b}";
                    listBox1.Items.Add(s);
                }
                else
                {
                    MessageBox.Show($" {a} меньше {b}");
                    string s = "";
                    s = $" {a} меньше {b}";
                    listBox1.Items.Add(s);
                }
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            double a, b;
            if (double.TryParse(textBox1.Text, out a) && double.TryParse(textBox2.Text, out b))
            {
                if (a >= b)
                {
                    MessageBox.Show($" {a}  меньше или равен {b}");
                    string s = "";
                    s = $" {a} меньше или равен {b}";
                    listBox1.Items.Add(s);
                }
                else
                {
                    MessageBox.Show($" {a} меньше {b}");
                    string s = "";
                    s = $" {a} меньше {b}";
                    listBox1.Items.Add(s);
                }
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button14_Click(object sender, EventArgs e)
        {
            double a, b;
            if (double.TryParse(textBox1.Text, out a) && double.TryParse(textBox2.Text, out b))
            {
                if (a == b)
                {
                    MessageBox.Show($" {a}  равен {b}");
                    string s = "";
                    s = $" {a} равен {b}";
                    listBox1.Items.Add(s);
                }
                else
                {
                    MessageBox.Show($" {a} не равен {b}");
                    string s = "";
                    s = $" {a} не равен {b}";
                    listBox1.Items.Add(s);
                }
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            double a; //число
            double b;//основание
            double res;

            if (double.TryParse(textBox1.Text, out a) && double.TryParse(textBox2.Text, out b))
            {
                res = Math.Log(a, b);
                MessageBox.Show(res.ToString());
                string s = "";
                s = a.ToString() + "log" + b.ToString() + " = " + res.ToString();

                listBox1.Items.Add(s);
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {

            double a; 
            double res;

            if (double.TryParse(textBox1.Text, out a))
            {
                res = Math.Cos(a);
                MessageBox.Show(res.ToString());
                string s = "";
                s = a.ToString() + "cos" + " = " + res.ToString();

                listBox1.Items.Add(s);
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {


            double a;
            double res;

            if (double.TryParse(textBox1.Text, out a))
            {
                res = Math.Cos(a)/Math.Sin(a);
                MessageBox.Show(res.ToString());
                string s = "";
                s = a.ToString() + "ctan" + " = " + res.ToString();

                listBox1.Items.Add(s);
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            double a, b, res;

            if (double.TryParse(textBox1.Text, out a) && double.TryParse(textBox2.Text, out b))
            {
                res =Math.Pow(a, b); ;
                MessageBox.Show("Результат: " + res.ToString());
                string s = "";
                s = a.ToString() + "^" + b.ToString() + " = " + Math.Pow(a, b).ToString();

                listBox1.Items.Add(s);
            }
            else
            {
                MessageBox.Show("Неверные аргументы", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}